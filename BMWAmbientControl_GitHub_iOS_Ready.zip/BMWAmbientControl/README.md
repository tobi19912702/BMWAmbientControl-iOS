# BMW Ambient Control – native iOS BLE-App (erweiterte Version)

## Installation / Xcode

1. Mac mit Xcode: File > New > Project > iOS > App, Product Name `BMWAmbientControl`, SwiftUI, Swift, iOS 16 oder neuer.
2. Die drei Swift-Dateien aus diesem Ordner ins Projekt übernehmen. Die generierte `BMWAmbientControlApp.swift` ersetzen, nicht doppelt einbinden.
3. Target > Info: `NSBluetoothAlwaysUsageDescription` = `Bluetooth wird benötigt, um die BMW-Ambientebeleuchtung zu verbinden und zu steuern.`
4. Unter Signing & Capabilities das eigene Development Team auswählen. Echtes iPhone als Ziel wählen und Run drücken. Ggf. Entwickler-Modus aktivieren.
5. BLE funktioniert nicht im iOS-Simulator. Die App wurde hier nicht mit Xcode kompiliert oder an realen Controllern getestet.

## Unterstützt

- CoreBluetooth-Scan, Verbinden, Trennen, GATT FFF0 / FFF3 (Write Without Response) / FFF4 (Notify), Hex-Diagnoseprotokoll.
- Zwei getrennte Zonen und lokale RGB-Farbwahl über ColorPicker oder HEX (`#RRGGBB`), 24-Bit-Farbraum, Favoriten, lokale Speicherung.
- TWETIZ ELK-BLEDOM: **bestätigter** Rotbefehl `7E070503FF000010EF`.
- TWETIZ: **experimenteller** Farbtest mit Paket-Hypothese `7E070503RRGGBB10EF` nach expliziter Freigabe. Bytes 4–6 als RGB sind abgeleitet, NICHT bestätigt. Byte 7 `10` ist nicht verifiziert. Farbtests nur nach eigenem Ermessen und einzeln per Tastendruck; kein automatischer Versand.
- Helligkeitsregler skaliert RGB-Werte; das ist **kein** bestätigter Hardware-Helligkeitsbefehl.
- Dreamcolor MELK-OA21PQ EA: BLE-Verbindung, Diagnose und lokal gespeicherte Farben. **Keine** unbestätigten RGB-Pakete werden an diesen Controller gesendet.

## Noch nicht möglich

- Vollständige bestätigte RGB-, Effekt- oder Helligkeitssteuerung beider Controller.
- Dauerhaftes Ändern der Firmware-Startanimation; hierfür fehlen bestätigte Befehle.
- Automatischer Reconnect und verlässliches automatisches Senden beim Fahrzeugstart.
- Fertig signierte IPA-Datei: Hier wird Quellcode bereitgestellt, kein iOS-Build.

## Tests

Zunächst mit ELK-BLEDOM verbinden, `Rot (bestätigt)` drücken und die Wirkung prüfen. Anschließend experimentelle Tests nur nach ausdrücklicher Freigabe mit einer einzelnen Farbe durchführen und die Reaktion protokollieren. Für Dreamcolor erst die zugehörigen Original-App-Befehle ermitteln.
