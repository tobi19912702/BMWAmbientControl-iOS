import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var bluetooth: BluetoothManager
    @AppStorage("twetizHex") private var twetizHex = "#FF0000"
    @AppStorage("dreamcolorHex") private var dreamcolorHex = "#FF0000"
    @AppStorage("twetizBrightness") private var twetizBrightness = 1.0
    @AppStorage("dreamcolorBrightness") private var dreamcolorBrightness = 1.0
    @AppStorage("favoriteColors") private var favoritesJSON = "[\"#FF0000\",\"#00FF00\",\"#0000FF\",\"#FFFFFF\",\"#FFAA00\"]"
    @State private var selectedTab = 0
    @State private var confirmExperimental = false

    private var favorites: [String] {
        (try? JSONDecoder().decode([String].self, from: Data(favoritesJSON.utf8))) ?? []
    }
    private func saveFavorite(_ hex: String) {
        var updated = favorites
        if !updated.contains(hex) { updated.append(hex) }
        if let data = try? JSONEncoder().encode(updated), let string = String(data: data, encoding: .utf8) {
            favoritesJSON = string
        }
    }

    var body: some View {
        TabView(selection: $selectedTab) {
            controlTab.tabItem { Label("Farben", systemImage: "paintpalette") }.tag(0)
            devicesTab.tabItem { Label("Geräte", systemImage: "antenna.radiowaves.left.and.right") }.tag(1)
            diagnosticsTab.tabItem { Label("Diagnose", systemImage: "waveform.path.ecg") }.tag(2)
            startupTab.tabItem { Label("Start", systemImage: "sparkles") }.tag(3)
        }
        .tint(.cyan)
        .preferredColorScheme(.dark)
        .alert("Experimentelle RGB-Befehle aktivieren?", isPresented: $confirmExperimental) {
            Button("Abbrechen", role: .cancel) { bluetooth.experimentalTWETIZEnabled = false }
            Button("Ich akzeptiere das Risiko") { bluetooth.experimentalTWETIZEnabled = true }
        } message: {
            Text("Nur Rot wurde mit TWETIZ getestet. Andere RGB-Pakete sind eine unbestätigte Ableitung. Fehlfunktionen sind möglich. Keine Befehle werden an Dreamcolor gesendet.")
        }
    }

    private var controlTab: some View {
        NavigationStack {
            List {
                Section {
                    Text("Die Farbauswahl unterstützt alle 16,7 Millionen 24-Bit-RGB-Farben. Die tatsächliche Hardwaresteuerung ist nur für TWETIZ-Rot bestätigt.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                zoneEditor(title: "TWETIZ · Lichtleisten", name: "ELK-BLEDOM", hex: $twetizHex, brightness: $twetizBrightness, twetiz: true)
                zoneEditor(title: "Dreamcolor · Innenraum", name: "MELK-OA21PQ EA", hex: $dreamcolorHex, brightness: $dreamcolorBrightness, twetiz: false)
                Section("Experimentelle Steuerung") {
                    Toggle("TWETIZ RGB-Test freigeben", isOn: Binding(
                        get: { bluetooth.experimentalTWETIZEnabled },
                        set: { enabled in
                            if enabled { confirmExperimental = true }
                            else { bluetooth.experimentalTWETIZEnabled = false }
                        }
                    ))
                    Text("RGB-Hypothese: 7E070503 R G B 10 EF. Das Byte 10 ist nicht verifiziert. Der Regler skaliert RGB-Werte als Näherung, nicht als bestätigter Helligkeitsbefehl.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("BMW Ambient Control")
        }
    }

    private func zoneEditor(title: String, name: String, hex: Binding<String>, brightness: Binding<Double>, twetiz: Bool) -> some View {
        Section(title) {
            let rgb = RGBColor(hex: hex.wrappedValue) ?? RGBColor(255, 0, 0)
            ColorPicker("Farbe auswählen", selection: Binding(
                get: { rgb.color },
                set: { hex.wrappedValue = RGBColor(color: $0).hex }
            ), supportsOpacity: false)
            HStack {
                TextField("HEX #RRGGBB", text: hex)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                    .font(.system(.body, design: .monospaced))
                RoundedRectangle(cornerRadius: 8).fill(rgb.color).frame(width: 44, height: 30)
            }
            HStack {
                Text("Helligkeit (RGB-Skalierung)")
                Spacer()
                Text("\(Int(brightness.wrappedValue * 100)) %").foregroundStyle(.secondary)
            }.font(.caption)
            Slider(value: brightness, in: 0...1, step: 0.01)
            HStack {
                Button("Als Favorit speichern") { saveFavorite(rgb.hex) }
                    .buttonStyle(.bordered)
                if twetiz {
                    Button("Rot (bestätigt)") {
                        if let id = bluetooth.devices.first(where: { bluetooth.isTWETIZ($0.id) && bluetooth.isReady($0.id) })?.id {
                            bluetooth.sendVerifiedRed(to: id)
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(!bluetooth.devices.contains(where: { bluetooth.isTWETIZ($0.id) && bluetooth.isReady($0.id) }))
                }
            }
            if !favorites.isEmpty {
                ScrollView(.horizontal) {
                    HStack {
                        ForEach(favorites, id: \.self) { favorite in
                            if let color = RGBColor(hex: favorite) {
                                Button { hex.wrappedValue = color.hex } label: {
                                    Circle().fill(color.color).frame(width: 34, height: 34)
                                        .overlay(Circle().stroke(.white.opacity(0.35)))
                                }.accessibilityLabel("Farbe \(favorite)")
                            }
                        }
                    }
                }
            }
            if twetiz {
                let ready = bluetooth.devices.first(where: { bluetooth.isTWETIZ($0.id) && bluetooth.isReady($0.id) })
                Button("Ausgewählte Farbe experimentell senden") {
                    guard let id = ready?.id, let color = RGBColor(hex: hex.wrappedValue) else { return }
                    bluetooth.sendExperimentalTWETIZColor(color.dimmed(brightness.wrappedValue), to: id)
                }
                .disabled(ready == nil || !bluetooth.experimentalTWETIZEnabled || RGBColor(hex: hex.wrappedValue) == nil)
                Text("Für andere Farben als Rot ist der tatsächliche Effekt nicht bestätigt.")
                    .font(.caption).foregroundStyle(.orange)
            } else {
                Text("Farben werden lokal gespeichert. Für Dreamcolor ist noch kein bestätigter RGB-Befehl vorhanden; Senden ist deaktiviert.")
                    .font(.caption).foregroundStyle(.orange)
            }
            Text("BLE-Name: \(name)").font(.caption).foregroundStyle(.secondary)
        }
    }

    private var devicesTab: some View {
        NavigationStack {
            List {
                Section("Bluetooth") {
                    Text(bluetooth.status).foregroundStyle(.secondary)
                    HStack {
                        Button("Geräte suchen") { bluetooth.scan() }.buttonStyle(.borderedProminent)
                        Button("Scan stoppen") { bluetooth.stopScan() }.buttonStyle(.bordered)
                    }
                }
                Section("Gefundene Geräte") {
                    if bluetooth.devices.isEmpty {
                        Text("Noch keine Geräte gefunden. Scan starten und Beleuchtung einschalten.")
                            .foregroundStyle(.secondary)
                    }
                    ForEach(bluetooth.devices) { device in
                        VStack(alignment: .leading, spacing: 8) {
                            Text(device.name).font(.headline)
                            Text("Signal: \(device.rssi) dBm · \(bluetooth.connections[device.id] ?? "Nicht verbunden")")
                                .font(.caption).foregroundStyle(.secondary)
                            HStack {
                                Button("Verbinden") { bluetooth.connect(device.id) }.buttonStyle(.bordered)
                                Button("Trennen") { bluetooth.disconnect(device.id) }.buttonStyle(.bordered)
                            }
                        }.padding(.vertical, 4)
                    }
                }
                Section("Zonenzuordnung") {
                    LabeledContent("TWETIZ", value: "ELK-BLEDOM")
                    LabeledContent("Dreamcolor", value: "MELK-OA21PQ EA")
                }
            }
            .navigationTitle("BLE-Geräte")
        }
    }

    private var diagnosticsTab: some View {
        NavigationStack {
            List {
                Section("BLE-Protokoll") {
                    LabeledContent("GATT-Service", value: "FFF0")
                    LabeledContent("Schreiben", value: "FFF3")
                    LabeledContent("Benachrichtigung", value: "FFF4")
                }
                Section("Ereignisprotokoll") {
                    if bluetooth.logs.isEmpty { Text("Noch keine Ereignisse") }
                    ForEach(Array(bluetooth.logs.enumerated()), id: \.offset) { _, entry in
                        Text(entry).font(.system(size: 12, design: .monospaced)).textSelection(.enabled)
                    }
                    ShareLink("Protokoll exportieren", item: bluetooth.logs.joined(separator: "\n"))
                }
            }.navigationTitle("Diagnose")
        }
    }

    private var startupTab: some View {
        NavigationStack {
            List {
                Section("Startanimationen") {
                    Text("TWETIZ: Kein verifizierter Befehl zum dauerhaften Ändern der Startanimation bekannt.")
                    Text("Dreamcolor: Regenbogen-Startanimation bekannt, aber kein bestätigter Befehl zum Überschreiben.")
                }
                Section("Sicherheit") {
                    Text("Die App sendet keine unbekannten Firmware- oder Speicherbefehle. Experimentelle TWETIZ-Farben verändern nach derzeitigem Kenntnisstand keine persistenten Einstellungen.")
                        .foregroundStyle(.secondary)
                }
            }.navigationTitle("Startanimation")
        }
    }
}
