import Foundation
import CoreBluetooth
import SwiftUI

struct DiscoveredDevice: Identifiable {
    let id: UUID
    var name: String
    var rssi: Int
}

struct RGBColor: Codable, Equatable {
    var red: UInt8
    var green: UInt8
    var blue: UInt8
    init(_ red: UInt8, _ green: UInt8, _ blue: UInt8) {
        self.red = red; self.green = green; self.blue = blue
    }
    init(color: Color) {
        let ui = UIColor(color)
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        ui.getRed(&r, green: &g, blue: &b, alpha: &a)
        self.init(UInt8((r * 255).rounded()), UInt8((g * 255).rounded()), UInt8((b * 255).rounded()))
    }
    var color: Color { Color(red: Double(red)/255, green: Double(green)/255, blue: Double(blue)/255) }
    var hex: String { String(format: "#%02X%02X%02X", red, green, blue) }
    init?(hex: String) {
        let value = hex.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "#", with: "")
        guard value.count == 6, let number = UInt32(value, radix: 16) else { return nil }
        self.init(UInt8((number >> 16) & 0xFF), UInt8((number >> 8) & 0xFF), UInt8(number & 0xFF))
    }
    func dimmed(_ brightness: Double) -> RGBColor {
        let factor = min(max(brightness, 0), 1)
        return RGBColor(UInt8((Double(red) * factor).rounded()), UInt8((Double(green) * factor).rounded()), UInt8((Double(blue) * factor).rounded()))
    }
}

final class BluetoothManager: NSObject, ObservableObject {
    @Published private(set) var devices: [DiscoveredDevice] = []
    @Published private(set) var status = "Bluetooth wird initialisiert"
    @Published private(set) var connections: [UUID: String] = [:]
    @Published private(set) var logs: [String] = []
    @Published var experimentalTWETIZEnabled = false

    private var central: CBCentralManager!
    private var peripherals: [UUID: CBPeripheral] = [:]
    private var writers: [UUID: CBCharacteristic] = [:]
    private var discoveredNames: [UUID: String] = [:]
    private let serviceUUID = CBUUID(string: "FFF0")
    private let writeUUID = CBUUID(string: "FFF3")
    private let notifyUUID = CBUUID(string: "FFF4")

    override init() {
        super.init()
        central = CBCentralManager(delegate: self, queue: .main)
    }

    func scan() {
        guard central.state == .poweredOn else { log("Scan nicht möglich: \(status)"); return }
        devices.removeAll()
        central.scanForPeripherals(withServices: nil, options: [CBCentralManagerScanOptionAllowDuplicatesKey: false])
        log("BLE-Scan gestartet")
    }
    func stopScan() { central.stopScan(); log("Scan beendet") }
    func connect(_ id: UUID) {
        guard let peripheral = peripherals[id] else { log("Gerät nicht verfügbar"); return }
        central.stopScan()
        connections[id] = "Verbinde …"
        central.connect(peripheral, options: nil)
    }
    func disconnect(_ id: UUID) {
        guard let peripheral = peripherals[id] else { return }
        central.cancelPeripheralConnection(peripheral)
    }
    func isTWETIZ(_ id: UUID) -> Bool { discoveredNames[id] == "ELK-BLEDOM" }
    func isDreamcolor(_ id: UUID) -> Bool { discoveredNames[id] == "MELK-OA21PQ EA" }
    func isReady(_ id: UUID) -> Bool {
        peripherals[id]?.state == .connected && writers[id] != nil
    }

    func sendVerifiedRed(to id: UUID) {
        guard isTWETIZ(id) else { log("Rotbefehl nur für ELK-BLEDOM bestätigt"); return }
        write([0x7E,0x07,0x05,0x03,0xFF,0x00,0x00,0x10,0xEF], to: id, description: "Bestätigter Rotbefehl")
    }

    func sendExperimentalTWETIZColor(_ color: RGBColor, to id: UUID) {
        guard experimentalTWETIZEnabled else { log("Experimentelle RGB-Befehle sind gesperrt"); return }
        guard isTWETIZ(id) else { log("Experimentelles TWETIZ-Format nicht an andere Geräte senden"); return }
        // Hypothese aus dem bestätigten Rotpaket: Bytes 4-6 = R,G,B.
        // Byte 7 (0x10) ist NICHT als Prüfsumme oder Modus verifiziert.
        // Dieser Befehl darf nur nach ausdrücklicher Freigabe getestet werden.
        let packet: [UInt8] = [0x7E,0x07,0x05,0x03,color.red,color.green,color.blue,0x10,0xEF]
        write(packet, to: id, description: "EXPERIMENTELL \(color.hex)")
    }

    private func write(_ bytes: [UInt8], to id: UUID, description: String) {
        guard let peripheral = peripherals[id], peripheral.state == .connected,
              let writer = writers[id], writer.properties.contains(.writeWithoutResponse) else {
            log("Nicht gesendet: Gerät oder FFF3 nicht bereit"); return
        }
        guard peripheral.canSendWriteWithoutResponse else {
            log("Nicht gesendet: BLE-Schreibpuffer momentan voll. Bitte erneut versuchen."); return
        }
        peripheral.writeValue(Data(bytes), for: writer, type: .withoutResponse)
        log("\(description) an \(discoveredNames[id] ?? "Gerät"): \(bytes.map { String(format: "%02X", $0) }.joined())")
    }
    private func log(_ message: String) {
        let formatter = DateFormatter(); formatter.dateFormat = "HH:mm:ss"
        logs.append("[\(formatter.string(from: Date()))] \(message)")
        if logs.count > 500 { logs.removeFirst(logs.count - 500) }
    }
}

extension BluetoothManager: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOn: status = "Bluetooth bereit"
        case .poweredOff: status = "Bluetooth ausgeschaltet"
        case .unauthorized: status = "Bluetooth-Berechtigung fehlt"
        case .unsupported: status = "BLE nicht unterstützt"
        case .resetting: status = "Bluetooth wird zurückgesetzt"
        case .unknown: status = "Bluetooth-Status unbekannt"
        @unknown default: status = "Unbekannter Bluetooth-Status"
        }
        log(status)
    }
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral,
                        advertisementData: [String: Any], rssi RSSI: NSNumber) {
        let advertised = advertisementData[CBAdvertisementDataLocalNameKey] as? String
        let name = advertised ?? peripheral.name ?? "Unbenanntes BLE-Gerät"
        guard name == "ELK-BLEDOM" || name == "MELK-OA21PQ EA" else { return }
        peripherals[peripheral.identifier] = peripheral
        discoveredNames[peripheral.identifier] = name
        let device = DiscoveredDevice(id: peripheral.identifier, name: name, rssi: RSSI.intValue)
        if let index = devices.firstIndex(where: { $0.id == device.id }) { devices[index] = device }
        else { devices.append(device) }
    }
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        connections[peripheral.identifier] = "Verbunden – suche Dienste"
        peripheral.delegate = self
        peripheral.discoverServices([serviceUUID])
        log("Verbunden: \(discoveredNames[peripheral.identifier] ?? "Gerät")")
    }
    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        connections[peripheral.identifier] = "Verbindung fehlgeschlagen"
        log("Verbindungsfehler: \(error?.localizedDescription ?? "unbekannt")")
    }
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        connections[peripheral.identifier] = "Getrennt"
        writers.removeValue(forKey: peripheral.identifier)
        log("Getrennt: \(discoveredNames[peripheral.identifier] ?? "Gerät") \(error?.localizedDescription ?? "")")
    }
}

extension BluetoothManager: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let error { log("Dienstsuche fehlgeschlagen: \(error.localizedDescription)"); return }
        guard let services = peripheral.services, !services.isEmpty else { log("FFF0 nicht gefunden"); return }
        for service in services {
            log("Dienst: \(service.uuid.uuidString)")
            peripheral.discoverCharacteristics([writeUUID, notifyUUID], for: service)
        }
    }
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        if let error { log("Characteristic-Suche fehlgeschlagen: \(error.localizedDescription)"); return }
        for characteristic in service.characteristics ?? [] {
            log("Characteristic: \(characteristic.uuid.uuidString), Eigenschaften: \(characteristic.properties.rawValue)")
            if characteristic.uuid == writeUUID && characteristic.properties.contains(.writeWithoutResponse) {
                writers[peripheral.identifier] = characteristic
                connections[peripheral.identifier] = "Verbunden – FFF3 bereit"
            }
            if characteristic.uuid == notifyUUID && characteristic.properties.contains(.notify) {
                peripheral.setNotifyValue(true, for: characteristic)
            }
        }
    }
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        if let error { log("Notify-Fehler: \(error.localizedDescription)"); return }
        guard let data = characteristic.value else { return }
        log("\(discoveredNames[peripheral.identifier] ?? "Gerät") \(characteristic.uuid.uuidString): \(data.map { String(format: "%02X", $0) }.joined())")
    }
    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        if let error { log("Notify-Aktivierung fehlgeschlagen: \(error.localizedDescription)") }
        else { log("Notify \(characteristic.uuid.uuidString): \(characteristic.isNotifying ? "aktiv" : "inaktiv")") }
    }
}
