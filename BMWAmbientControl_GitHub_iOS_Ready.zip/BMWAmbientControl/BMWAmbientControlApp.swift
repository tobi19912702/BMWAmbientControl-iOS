import SwiftUI

@main
struct BMWAmbientControlApp: App {
    @StateObject private var bluetooth = BluetoothManager()
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(bluetooth)
        }
    }
}
