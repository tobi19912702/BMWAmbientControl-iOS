# BMW Ambiente Control – native iPhone-App ohne Mac

**Technik:** SwiftUI + CoreBluetooth | iOS 16+ | XcodeGen | GitHub Actions (macOS) | Sideloadly (Windows)

## Projekt aus einer älteren Version übernommen

Die Swift-Quellen basieren auf `BMWAmbientControl_iOS_Source_v2.zip` (23.11.2026).
In diesem Paket wurden eine XcodeGen-Projektkonfiguration und eine GitHub-Actions-Build-Automation ergänzt.
Die BLE-Suche zeigt nur die bereits identifizierten Controller an.

### Zonen
- `ELK-BLEDOM` = TWETIZ, Lichtleisten in Türen und Armaturenbrett
- `MELK-OA21PQ EA` = Dreamcolor, Fußraum, Lautsprecher, Türgriffe, Türtaschen
- Beide: GATT `FFF0`, FFF3 Write Without Response, FFF4 Notify
- Bestätigter **TWETIZ-Rotbefehl**: `7E070503FF000010EF`
- Die v2-App behandelt andere TWETIZ-RGB-Pakete als **experimentell**.
- Für Dreamcolor ist in dieser nativen Version **kein RGB-Schreibbefehl freigegeben**.
- Firmware-Startanimation und automatisches Anlaufen mit der Zündung **nicht** bestätigt.
- Die letzte Einstellung speichern die Controller selbst.

## Kostenloser Build per GitHub Actions (kein Mac erforderlich)
1. GitHub-Konto erstellen oder anmelden: https://github.com/
2. Neues Repository erstellen, z. B. `BMWAmbientControl-iOS` (privat möglich; die kostenlosen Actions-Minuten beachten).
3. Den **INHALT** dieses ZIPs, inklusive `.github/workflows/build-ios.yml`, in das Repository übernehmen.
   Am einfachsten über GitHub Desktop für Windows: https://desktop.github.com/
4. In GitHub: Repository → Actions → `Build native iPhone IPA (ohne Signierung)` → **Run workflow**.
5. Nach erfolgreich abgeschlossener Aktion den Eintrag `BMWAmbientControl-unsigned-IPA` unter Artifacts herunterladen.
6. Das heruntergeladene **GitHub-Artefakt-ZIP entpacken**. Darin liegt `BMWAmbientControl-unsigned.ipa`.

### Installation am Windows-PC mit Sideloadly
1. Sideloadly nur von https://sideloadly.io/ installieren.
2. iPhone per Datenkabel anschließen und auf dem iPhone „Diesem Computer vertrauen“ bestätigen.
3. Die `.ipa` in Sideloadly ziehen, Apple-ID **ausschließlich in Sideloadly** eingeben.
4. Installation starten. Bei Bedarf am iPhone `Einstellungen → Datenschutz & Sicherheit → Entwicklermodus` aktivieren (Neustart).
5. Unter `Einstellungen → Allgemein → VPN & Geräteverwaltung` die eigene Entwickler-App vertrauen.
6. Beim ersten App-Start Bluetooth-Zugriff erlauben.
7. Unter `Geräte` suchen, TWETIZ verbinden und mit `Rot (bestätigt)` testen.
8. Sideloadly-Auto-Refresh einschalten. Eine kostenlose Apple-ID signiert in der Regel **nur für 7 Tage**.
   Sideloadly benötigt zur automatischen Auffrischung den Windows-PC und Verbindung via USB oder WLAN.

**Wichtig:** Das GitHub-IPA ist *unsigniert*. Du kannst es nicht direkt durch Antippen auf dem iPhone installieren.
Die App wurde in dieser Umgebung nur statisch geprüft, noch nicht auf einem macOS-Runner gebaut oder an den realen Controllern getestet.

## Datenschutz und Sicherheit
- Keine Apple-ID, Zertifikate oder Passwörter im Repository hinterlegen.
- Keine unbekannten Firmware-/DFU-Kommandos an die LED-Controller senden.
- GitHub-Repository am besten privat halten, wenn die Quelltexte nicht öffentlich sein sollen.
- GitHub Actions hat bei privaten Repositories planabhängige Gratis-Kontingente; darüber hinaus können Gebühren entstehen.

## Quellen
Apple Free Developer Account: https://developer.apple.com/help/account/basics/about-your-developer-account/
GitHub Actions: https://docs.github.com/en/actions/concepts/billing-and-usage
Sideloadly: https://sideloadly.io/faq.html
